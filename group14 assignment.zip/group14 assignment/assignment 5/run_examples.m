%% run_examples.m
% Run demos: root finding, ODE solvers, integration ---> prints results & saves plots

clear; close all; clc;

%% PART A: Root finding demo
fprintf('--- Root finding demo ---\n');
f = @(x) x.^3 - x - 2;
df = @(x) 3*x.^2 - 1;

tic; [r_nr, it_nr] = NumericalMethod.newtonRaphson(f, df, 1.5, 1e-8, 100); t_nr = toc;
fprintf('Newton-Raphson: root=%.8f, iter=%d, time=%.6f s\n', r_nr, it_nr, t_nr);

tic; [r_sec, it_sec] = NumericalMethod.secantMethod(f, 1, 2, 1e-8, 100); t_sec = toc;
fprintf('Secant:         root=%.8f, iter=%d, time=%.6f s\n', r_sec, it_sec, t_sec);

tic; [r_bi, it_bi] = NumericalMethod.bisectionMethod(f, 1, 2, 1e-8, 100); t_bi = toc;
fprintf('Bisection:      root=%.8f, iter=%d, time=%.6f s\n', r_bi, it_bi, t_bi);

figure; bar([t_nr, t_sec, t_bi]);
set(gca, 'XTickLabel', {'Newton','Secant','Bisection'});
ylabel('time (s)'); title('Root finding computation time');
saveas(gcf, 'root_times.png');

%% PART B: ODE demo
fprintf('\n--- ODE demo ---\n');
odefun = @(t,y) -2*y + exp(-t);
y_analytic = @(t) (1/3)*exp(-2*t) + (2/3)*exp(-t);

t0 = 0; tf = 5; y0 = 1; h = 0.1;
odeObj = DiffProblem(odefun, y_analytic, t0, tf, y0, h);
odeObj.info();

methods = {'Euler','RK2','RK4'};
results = cell(1,numel(methods));
for k = 1:numel(methods)
    results{k} = odeObj.solve(methods{k});
    fprintf('%s: time=%.6f s, maxErr=%.6e\n', methods{k}, results{k}.time, results{k}.maxError);
end

t = odeObj.tVals;
y_true = y_analytic(t);
figure; plot(t, y_true, 'k-', 'LineWidth', 1.8); hold on;
plot(t, results{1}.y, '--'); plot(t, results{2}.y, '-.'); plot(t, results{3}.y, ':');
legend('Analytical','Euler','RK2','RK4','Location','best');
xlabel('t'); ylabel('y(t)'); title('ODE: Analytical vs Numerical'); grid on;
saveas(gcf, 'ode_compare.png');

figure; bar([results{1}.time, results{2}.time, results{3}.time]);
set(gca, 'XTickLabel', methods); ylabel('time (s)'); title('ODE methods computation time');
saveas(gcf, 'ode_times.png');

%% PART C: Integration demo
fprintf('\n--- Integration demo ---\n');
fint = @(x) sin(x).^2;
a = 0; b = pi; n = 200;   % n must be even for Simpson
intObj = IntegralProblem(fint, a, b, n);
intObj.info();

resTrap = intObj.solve('Trapezoid');
resSimp = intObj.solve('Simpson');

I_true = pi/2;
fprintf('Trapezoid: I=%.8f, time=%.6f, err=%.6e\n', resTrap.I, resTrap.time, abs(resTrap.I - I_true));
fprintf('Simpson:   I=%.8f, time=%.6f, err=%.6e\n', resSimp.I, resSimp.time, abs(resSimp.I - I_true));

figure; bar([resTrap.time, resSimp.time]); set(gca,'XTickLabel',{'Trapezoid','Simpson'});
ylabel('time (s)'); title('Integration computation time');
saveas(gcf, 'int_times.png');

intObj.plot(resSimp);
saveas(gcf, 'integrand_area.png');

fprintf('\nAll demos finished. Figures saved to current folder.\n');

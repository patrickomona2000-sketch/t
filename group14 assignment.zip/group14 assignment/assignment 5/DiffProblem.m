classdef DiffProblem < NumericalMethod
    % DiffProblem  For initial value ODE problems (Euler, RK2, RK4)
    
    properties
        odefun      % function handle f(t,y)
        analytical  % function handle for analytical solution y(t) (or [] if none)
        t0
        tf
        y0
        h
        tVals
    end
    
    methods
        function obj = DiffProblem(odefun, analytical, t0, tf, y0, h)
            if nargin < 6
                error('Provide odefun, analytical (or []), t0, tf, y0, h');
            end
            obj.odefun = odefun;
            obj.analytical = analytical;
            obj.t0 = t0; obj.tf = tf; obj.y0 = y0; obj.h = h;
            obj.tVals = t0:h:tf;
        end
        
        function res = solve(obj, methodName)
            t = obj.tVals;
            N = numel(t);
            switch lower(methodName)
                case 'euler'
                    y = zeros(1,N); y(1) = obj.y0;
                    tic;
                    for i = 1:N-1
                        y(i+1) = y(i) + obj.h * obj.odefun(t(i), y(i));
                    end
                    elapsed = toc;
                case 'rk2'
                    y = zeros(1,N); y(1) = obj.y0;
                    tic;
                    for i = 1:N-1
                        k1 = obj.odefun(t(i), y(i));
                        k2 = obj.odefun(t(i) + obj.h, y(i) + obj.h*k1);
                        y(i+1) = y(i) + obj.h/2*(k1 + k2);
                    end
                    elapsed = toc;
                case 'rk4'
                    y = zeros(1,N); y(1) = obj.y0;
                    tic;
                    for i = 1:N-1
                        k1 = obj.odefun(t(i), y(i));
                        k2 = obj.odefun(t(i) + obj.h/2, y(i) + obj.h*k1/2);
                        k3 = obj.odefun(t(i) + obj.h/2, y(i) + obj.h*k2/2);
                        k4 = obj.odefun(t(i) + obj.h, y(i) + obj.h*k3);
                        y(i+1) = y(i) + obj.h/6*(k1 + 2*k2 + 2*k3 + k4);
                    end
                    elapsed = toc;
                otherwise
                    error('Unknown method: %s', methodName);
            end
            
            if ~isempty(obj.analytical)
                y_true = obj.analytical(t);
                maxErr = max(abs(y_true - y));
            else
                y_true = []; maxErr = NaN;
            end
            
            res.method = methodName;
            res.t = t;
            res.y = y;
            res.y_true = y_true;
            res.time = elapsed;
            res.maxError = maxErr;
        end
        
        function plot(obj, res)
            figure;
            hold on;
            if ~isempty(res.y_true)
                plot(res.t, res.y_true, 'k-', 'LineWidth', 1.8);
            end
            plot(res.t, res.y, '--', 'LineWidth', 1.2);
            if ~isempty(res.y_true)
                legend('Analytical', sprintf('%s Numeric', res.method), 'Location', 'best');
            else
                legend(sprintf('%s Numeric', res.method), 'Location', 'best');
            end
            xlabel('t'); ylabel('y(t)');
            title(sprintf('ODE solution: %s', res.method));
            grid on; hold off;
        end
        
        function info(obj)
            fprintf('DiffProblem: t in [%g, %g], h = %g, y0 = %g\n', obj.t0, obj.tf, obj.h, obj.y0);
        end
    end
end

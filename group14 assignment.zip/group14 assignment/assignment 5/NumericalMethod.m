classdef (Abstract) NumericalMethod
    % NumericalMethod  Abstract base class for numerical computations
    % Contains shared properties and static root-finding helpers.
    
    properties
        tol = 1e-6;
        maxIter = 1000;
    end
    
    methods (Abstract)
        result = solve(obj, methodName)   % Each subclass implements its own solve
        plot(obj, result)                 % Plot results (subclass specific)
        info(obj)                         % Print short info about the problem
    end
    
    methods (Static)
        %% Newton-Raphson
        function [root, iter] = newtonRaphson(f, df, x0, tol, maxIter)
            if nargin < 4 || isempty(tol), tol = 1e-6; end
            if nargin < 5 || isempty(maxIter), maxIter = 1000; end
            x = x0;
            for iter = 1:maxIter
                fx = f(x);
                dfx = df(x);
                if dfx == 0
                    error('Derivative zero encountered in Newton-Raphson.');
                end
                x_new = x - fx/dfx;
                if abs(x_new - x) < tol
                    root = x_new; return;
                end
                x = x_new;
            end
            error('Newton-Raphson did not converge in %d iterations', maxIter);
        end
        
        %% Secant Method
        function [root, iter] = secantMethod(f, x0, x1, tol, maxIter)
            if nargin < 4 || isempty(tol), tol = 1e-6; end
            if nargin < 5 || isempty(maxIter), maxIter = 1000; end
            for iter = 1:maxIter
                f0 = f(x0); f1 = f(x1);
                denom = (f1 - f0);
                if denom == 0
                    error('Zero denominator in secant method.');
                end
                x2 = x1 - f1*(x1 - x0)/denom;
                if abs(x2 - x1) < tol
                    root = x2; return;
                end
                x0 = x1; x1 = x2;
            end
            error('Secant method did not converge in %d iterations', maxIter);
        end
        
        %% Bisection Method
        function [root, iter] = bisectionMethod(f, a, b, tol, maxIter)
            if nargin < 4 || isempty(tol), tol = 1e-6; end
            if nargin < 5 || isempty(maxIter), maxIter = 1000; end
            fa = f(a); fb = f(b);
            if fa * fb > 0
                error('Bisection requires opposite signs at endpoints.');
            end
            for iter = 1:maxIter
                c = (a + b)/2;
                fc = f(c);
                if abs(fc) < tol || (b - a)/2 < tol
                    root = c; return;
                end
                if fa * fc < 0
                    b = c; fb = fc;
                else
                    a = c; fa = fc;
                end
            end
            error('Bisection did not converge in %d iterations', maxIter);
        end
    end
end

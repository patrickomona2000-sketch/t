classdef IntegralProblem < NumericalMethod
    % IntegralProblem  For definite integrals (Trapezoid, Simpson)
    
    properties
        f
        a
        b
        n
        x
    end
    
    methods
        function obj = IntegralProblem(f, a, b, n)
            if nargin < 4
                error('Provide f, a, b, n');
            end
            obj.f = f; obj.a = a; obj.b = b; obj.n = n;
            obj.x = linspace(a, b, n+1);
        end
        
        function res = solve(obj, methodName)
            switch lower(methodName)
                case 'trapezoid'
                    tic;
                    h = (obj.b - obj.a)/obj.n;
                    fx = obj.f(obj.x);
                    I = h*( 0.5*fx(1) + sum(fx(2:end-1)) + 0.5*fx(end) );
                    elapsed = toc;
                case 'simpson'
                    if mod(obj.n,2) ~= 0
                        error('Simpson''s rule requires n even.');
                    end
                    tic;
                    h = (obj.b - obj.a)/obj.n;
                    x = obj.x;
                    fx = obj.f(x);
                    I = fx(1) + fx(end) + 4*sum(fx(2:2:end-1)) + 2*sum(fx(3:2:end-2));
                    I = I * h/3;
                    elapsed = toc;
                otherwise
                    error('Unknown method: %s', methodName);
            end
            
            res.method = methodName;
            res.I = I;
            res.time = elapsed;
            res.n = obj.n;
        end
        
        function plot(obj, res)
            xx = linspace(obj.a, obj.b, 500);
            figure;
            plot(xx, obj.f(xx), 'LineWidth', 1.2); hold on;
            xs = linspace(obj.a, obj.b, 100);
            ys = obj.f(xs);
            area(xs, ys);
            title(sprintf('Integral via %s -> I = %.6g', res.method, res.I));
            xlabel('x'); ylabel('f(x)');
            grid on; hold off;
        end
        
        function info(obj)
            fprintf('IntegralProblem: integrate on [%g, %g] with n = %d\n', obj.a, obj.b, obj.n);
        end
    end
end
